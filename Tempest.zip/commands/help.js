const Discord = require('discord.js');

exports.run = (bot,message,args) => {
	const principal = new Discord.MessageEmbed()
		.setColor("#ff0015")
		.setTitle("Tempest Bot")
		.setURL("https://discord.com/oauth2/authorize?client_id=820606239682723881&permissions=8&scope=bot")
		.setDescription("Lista dos comandos")
		.setThumbnail('https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png')
		.setAuthor('Tempest Bot', 'https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png', 'https://discord.js.org')
		.addFields(
			{ name: "Comandos para Administração do servidor", value: "d!help administration" },
			{ name: "Comandos para ouvir músicas", value: "d!help music" },
			{ name: "Comandos Gerais", value: "d!help geral"},
			{ name: "Comandos para criação de memes", value: "d!help memes" },
			{ name: "Comandos Backup", value: "d!help backup" },
		)
		.setTimestamp();

	const administration = new Discord.MessageEmbed()
	    .setColor("#ff0015")
	    .setTitle("Tempest Bot")
      .setURL("https://discord.com/oauth2/authorize?client_id=820606239682723881&permissions=8&scope=bot")	    .setURL(
	    .setDescription("Comandos para Administração do servidor (Para utiliza-los você precisa da permissão de Administrador ou o cargo 'Rapid Admin')")
	    .setThumbnail('https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png')
	    .setAuthor('Tempest Bot', 'https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png', 'https://discord.js.org')
	    .addFields(
			{ name: "Bane usuários", value: "d!ban (Usuários)\n\nEx: d!ban @Test#0000 @A#5313" },
			{ name: "Kicka usuários", value: "d!kick (Usuários)\n\nEx: d!ban @Test#0000 @A#5313" },
			{ name: "Da o cargo 'Rapid Admin' a usuários", value: "d!setadmin (Usuários)\n\nEx: d!setadmin @Test#0000 @A#5313" },
			{ name: "Limpa o chat" ,value: "d!purge (Quantidade de mensagens a ser deletadas)\n\nEx: d!purge 10" },
			{ name: "Muta um usuário", value: "d!tempmute (Usuário) (Tempo - Padrão 15 minutos)\n\nEx: d!mute @Test#0000 1h(1 hora)" },
			{ name: "Desmuta um usuário", value: "d!unmute (Usuário)\n\nEx: d!unmute @Test#0000" },
			{ name: "Define o canal no qual será exibido alertas", value: "d!setalert (Nome do Canal)" },
			{ name: "Envia uma mensagem em formato embed (TODOS OS ARGUMENTOS DEVEM SER SEPARADOS POR ;)", value: "d!sendembed (Título) ; (Texto) ; (Thumbnail: opcional)" },
			{ name: "Cria backup do servidor (Cargos, canais, mensagems, etc)", value: "d!backup" },
			{ name: "Carrega um backup", value: "d!load (BACKUP ID)" },
			{ name: "Ativa ou desativa o sistema anti-flood", value: "d!antiflood" },
			{ name: "Desativa o chat", value: "d!lock <Canal (Opcional)>" },
			{ name: "Ativa novamente o chat", value: "d!unlock <Canal (Opcional)>" },
      { name: "Dar aviso para algum membro", value: "d!warn <membro>" },
               )
	    .setTimestamp();
	
	const music = new Discord.MessageEmbed()
		.setColor("#ff0015")
		.setTitle("Tempest Bot")
		.setURL("https://discord.com/oauth2/authorize?client_id=820606239682723881&permissions=8&scope=bot")
		.setDescription("Comandos para ouvir músicas")
		.setThumbnail('https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png')
		.setAuthor('Tempest Bot', 'https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png', 'https://discord.js.org')
		.addFields(
			{ name: "Adiciona uma música a fila de reprodução", value: "d!play (Nome ou Link do Youtube)\n\nEx: d!play União Flasco" },
			{ name: "Pausa uma música", value: "d!pause" },
			{ name: "Despausa uma música", value: "d!resume" },
			{ name: "Para a música que está tocando e limpa a fila" ,value: "d!stop" },
			{ name: "Define o volume da música", value: "d!volume 0.5" },
			{ name: "Pula para a próxima música da fila", value: "d!skip" },
			{ name: "Coloca a música em loop", value: "d!loop" },
		)
		.setTimestamp();

	const geral = new Discord.MessageEmbed()
		.setColor("#ff0015")
		.setTitle("Tempest Bot")
    .setURL("https://discord.com/oauth2/authorize?client_id=820606239682723881&permissions=8&scope=bot")
		.setDescription("Comandos para ouvir músicas")
		.setThumbnail('https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png')
		.setAuthor('Tempest Bot', 'https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png', 'https://discord.js.org')
		.addFields(
			{ name: "Exibe os comandos", value: "d!help" },
			{ name: "Exibe informações sobre o bot", value: "d!botinfo" },
			{ name: "Exibe informações sobre o servidor", value: "d!serverinfo" },
			{ name: "Baixar a foto de perfil de um usuário", value: "d!profile (Usuário)" },
			{ name: "Exibe a mensagem de convite do bot", value: "d!invite" },
			{ name: "Exibe uma mensagem de regras" ,value: "d!rules" },
			{ name: "Exibe uma mensagem de convite para o servidor", value: "d!serverinvite (Descrição)\n\nEx: r!serverinvite Convide seus amigos para se divertirem conosco!" },
		)
		.setTimestamp();

	const memes = new Discord.MessageEmbed()
		.setColor("#ff0015")
		.setTitle("Tempest Bot")
		.setURL("https://discord.com/oauth2/authorize?client_id=820606239682723881&permissions=8&scope=bot")
		.setDescription(
			"Comandos para criação de memes\n\n"+
			"**d!bobesponja (Texto)**\n"+
			"**d!bolsonaro (Imagem)**\n"+
			"**d!bolsonaro2 (Imagem)**\n"+
			"**d!changemymind (Texto)**\n"+
			"**d!monstro (Texto)**\n"+
			"**d!piseinamerda (Texto)**\n"
		)
		.setThumbnail('https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png')
		.setAuthor('Tempest Bot', 'https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png', 'https://discord.js.org')
		.setTimestamp();

	const backp = new Discord.MessageEmbed()
		.setColor("#ff0015")
		.setTitle("Tempest Bot")
		.setURL("https://discord.com/oauth2/authorize?client_id=734154625845952694&permissions=8&scope=bot")
		.setDescription(
			"Comandos para criação de memes\n\n"+
			"**d!backup**\n"+
			"**d!load (Backup ID)**\n"
		)
		.setThumbnail('https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png')
		.setAuthor('Tempest Bot', 'https://cdn.discordapp.com/app-icons/734154625845952694/8261474e8963b9e62bf19159ca52dcea.png', 'https://discord.js.org')
		.setTimestamp();

	if (!args[0]){
		message.channel.send(principal);
	} else if (args[0].toLowerCase() === "administration"){
		message.channel.send(administration);
	} else if (args[0].toLowerCase() === "music"){
		message.channel.send(music);
	} else if (args[0].toLowerCase() === "geral"){
		message.channel.send(geral);
	} else if (args[0].toLowerCase() === "memes"){
		message.channel.send(memes);
	} else if (args[0].toLowerCase() === "backup") {
		message.channel.send(backp);
	} else {
		message.channel.send(principal);
	}
}