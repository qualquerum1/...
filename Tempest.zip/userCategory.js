const categories = {
	USER: 'users',
	MOD: 'mods',
	ADM: 'admins',
};

module.exports = categories;